const WIDTH_SCREEN = 288.0;
const HEIGHT_SCREEN = 512.0;
const SCALE = 1.3;
const BIRD_SIZE_WIDTH = 34.0;
const BIRD_SIZE_HEIGHT = 24.0;
